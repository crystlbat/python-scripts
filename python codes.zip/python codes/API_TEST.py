import requests


plat_auth_token = {'Authorization': 'Bearer 1234567890',
                   "Accept": "application/json"}
final_file = []
param={'ids':"513003,513004,513007,513008,513010,51301"}
url = f"https://hpone-uanalyze.uniphore.com:90/analytics/contacts"
response = requests.get(url = url, headers = plat_auth_token, verify = False,params=param)
print(response.status_code)

res = response.json()


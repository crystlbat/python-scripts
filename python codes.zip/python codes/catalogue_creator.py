import requests
import json
import pandas as pd
import json

dict={
  "catalog": {
    "items": [
    ],
    "version": 0
  }
}
url='http://172.31.1.199:3360/entity-catalog'
#response=requests.post(url=url,json='',headers='',)
#catalog=response.json()
#print(catalog)
print(dict["catalog"]["items"])
entities_df=pd.read_csv("C:/Catalogue_creator/entites.csv")
print(entities_df)
for i in range(len(entities_df["Entity Names"])):
  dict_demo={'id':f"{i}",
             'name': f"{entities_df['Entity Names'][i]}",
             'type': 'string'}

  dict["catalog"]["items"].append(dict_demo)
print(dict["catalog"]["items"])
print(dict)
with open("C:/Catalogue_creator/catalogue.json","w") as output:
  json.dump(dict,output)
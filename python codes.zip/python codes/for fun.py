import os
import glob
import datetime
import wave


current_dir=os.getcwd()
print(current_dir)
input_path=str('C:/collated_calls/') #where calls for convertion has to be kept
output_path=str('C:\\output_files_splitted\\')


input_filenames=[]
print(input_path)
filenames=[]
filelist=glob.glob('C:/collated_calls/*.wav')
for file in filelist:
    filenames.append(os.path.basename(file))
print(filenames)


os.chdir('C:/Program Files (x86)/sox-14-4-2')
for file in filenames:
    sox_command_converted = f'sox {input_path + file} -b 16 -r 8k {output_path +"converted"+ file}'
    os.system(f'cmd /C "{sox_command_converted}"')
    #sox_command = f'sox --i {output_path +"converted"+ file}'
    #os.system(f'cmd /C "{sox_command}"')
import requests


#callList="513003,513004,513007,513008,513010,513011"

plat_auth_token = {'Authorization': 'Bearer 1234567890'}
params={}
final_file = []
url = f"http://172.31.1.137:3120/search?q='confirmation number'&categoryIds='12'&organizationId='10'&startTime=1656633600&endTime=1656763200"

r_call = requests.get(url = url, headers = plat_auth_token, verify= 'C:/Users/Bibin/Downloads/uniphore-com-chain(1).pem')
print(r_call.status_code)
print(r_call.json())
import numpy as np
import pandas as pd
import glob
import os
import openpyxl
from datetime import datetime



filenames_with_path=[]
inputfiles=[]
hit_check_df=pd.read_csv("C:/output mock hit/mock hit checker.csv")
outputfilepath='C:/output mock hit/'
#Masteroutputfile=outputfilepath+filename+'.txt'
filepath='C:/transcripts to check/'
tracker={}


filenames_with_path=glob.glob('C:/transcripts to check/*.txt')
for file in filenames_with_path:
    inputfiles.append(os.path.basename(file))
print(inputfiles)



def checker(filename):
    column_names = []
    workbook_address = f'C:/output mock hit/HIT CHECK REPOSITORY_{datetime.now().strftime("%m_%d_%Y")}.xlsx'
    try:
        wb = openpyxl.load_workbook(workbook_address)
        try:
            filelist = wb['List']
        except:
            wb.create_sheet("List")
            filelist = wb['List']

    except:
        workbook_address = f'C:/output mock hit/HIT CHECK REPOSITORY_{datetime.now().strftime("%m_%d_%Y")}.xlsx'
        wb = openpyxl.Workbook()
        wb.save(workbook_address)
        wb = openpyxl.load_workbook(workbook_address)       #created output file
        try:
            filelist = wb['List']
        except:
            wb.create_sheet("List")
            filelist = wb['List']

    wb.create_sheet(filename)

    sheet = wb[filename]
    masterfile = filepath+ filename
    Masteroutputfile=outputfilepath+' mock hit rate '+filename
    with open(masterfile, 'r') as tbr:
        lines = tbr.readlines()
        i=2
        filelist[f"A{i}"].value = filename
        for col in hit_check_df.columns:
            column_names.append(col)
        with open(Masteroutputfile,'w') as output:# the main process(enganum mattendi vennalo)
            for name in column_names:
                for line in lines:
                    for value in hit_check_df[name]:
                        if line.find(str(value).lower()) != -1 and str(value)!="nan":
                            print(f'br-{name} \n keyword:{value} \n line no: {lines.index(line)+1}\n line: {line}\n')
                            output.write(f'br-{name} \n keyword:{value} \n line no: {lines.index(line)+1} \n line:{line.replace(value,value.upper())} \n')
                            sheet['A1'].value = "ENTITY"
                            sheet['B1'].value = "KEYWORD"
                            sheet['C1'].value = "LINE"

                            sheet[f'A{i}'].value = name
                            sheet[f'B{i}'].value = value
                            sheet[f'C{i}'].value = line.replace(value,value.upper())
                            i+=1


    wb.save(workbook_address)
for file in inputfiles:
    checker(file)


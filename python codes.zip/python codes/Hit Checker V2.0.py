import numpy as np
import pandas as pd
import glob
import os
import openpyxl
from datetime import datetime


#column_names=[]
inputfiles=[]
hit_check_df=pd.read_csv("C:/output mock hit/mock hit checker.csv")
print(hit_check_df.head())
print(len(hit_check_df.columns))

outputfilepath='C:/output mock hit/'
#Masteroutputfile=outputfilepath+filename+'.txt'
filepath='C:/transcripts to check/'
tracker={}

workbook_address=f'C:/output mock hit/mock_hit_{datetime.now().strftime("%m_%d_%Y")}.xlsx'
wb=openpyxl.Workbook()
print(wb.sheetnames)
wb.save(workbook_address)

filenames_with_path=glob.glob('C:/transcripts to check/*.txt')
for file in filenames_with_path:
    inputfiles.append(os.path.basename(file))
print(inputfiles)

def checker(filename):
    column_names = []
    for col in hit_check_df.columns:
        column_names.append(col)

    wb = openpyxl.load_workbook(workbook_address)#created output file
    wb.create_sheet(filename)
    wb.create_sheet("List")
    filelist=wb['List']
    sheet = wb[filename]
    masterfile = filepath+ filename
    Masteroutputfile=outputfilepath+' mock hit rate '+filename
    with open(masterfile, 'r') as tbr:
        lines = tbr.readlines()
    for name in column_names:
        print(name)
for file in inputfiles:
    checker(file)

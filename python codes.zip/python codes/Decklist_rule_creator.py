import glob
import pandas as pd
import numpy as np
import json

data={ "skipOnFirstRuleApplied": str("false"),
  "skipOnFirstNonTriggeredRule": str("false"),
  "priorityThreshold": 10,
  "delimeter": ",",
  "components": [
    {
      "name": "Budget Body Sentence 1",
      "description": "Budget Body Sentence 1",
      "priority": 1,
     "condition": f"$.entity().containsAnyKeyPhrases().minOccurs().isTrue()",
      "actions": [
        "$.output=$.valueOf('entity_budget_body_sentence1')"
      ]
    }
  ]}


data_df=pd.read_csv("C:/Decklist_rules/rules_dictionary_source.csv")
column_names=data_df.columns.tolist()
print(column_names)

for column in column_names:

  values=[val for val in  data_df[column].tolist() if str(val) !="nan"]
  print(values)
  for i in range(len(values)):
    if i == 0:
      stri = f"'{values[i]}'"
    else:
      stri = stri + f",'{values[i]}'"




  count = len(values)
  if count == 3 or count == 2:
    count -= 1
    cond=data['components'][0]["condition"]=f"$.entity('{column}').containsAnyKeyPhrases({stri}).minOccurs({count}).isTrue()"

  elif count == 1:
    count = 0
    cond=data['components'][0]["condition"]=f"$.entity('{column}').containsAnyKeyPhrases({stri}).isTrue()"

  else:
    count -= 2
    cond=data['components'][0]["condition"]=f"$.entity('{column}').containsAnyKeyPhrases({stri.lower()}).minOccurs({count}).isTrue()"

  print(count)
  with open(f"C:/Decklist_rules/Decklist_rules_output/{column.replace('entity','rule')}.txt" ,'w') as output:
    data['components'][0]["name"]=column.replace('_',' ').replace('entity','')
    data['components'][0]["description"] = f"Rule to track {column}"
    data['components'][0]["condition"]=f"{cond}"
    data['components'][0]["actions"][0]=f"$.output=$.valueOf('{column}')"
    json.dump(data,output,indent=2)
  #print(data)
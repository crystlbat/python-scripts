import json
import glob
import os


swagger_payloads=r"C:\swagger\payloads"
input_files=glob.glob(f"{swagger_payloads}/*.json")

for file in input_files:
    filename=os.path.basename(file).replace(".json",".txt")
    print(filename)
    f=open(file)
    dict=json.load(f)
    with open(f'{swagger_payloads}/transcript_{filename}','w') as output:
        for line in dict['wsText']:
            output.write(line)

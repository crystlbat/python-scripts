import glob

file_list=glob.glob('')
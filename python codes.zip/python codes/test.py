values=["hello","how","hi"]
for i in range(len(values)):
    if i == 0:
        stri = f"'{values[i]}'"
    elif i == len(values) - 1:
        stri = stri + f"'{values[len(values) - 1]}'"
    else:
        stri = stri + f",'{values[i]}',"
print(stri)

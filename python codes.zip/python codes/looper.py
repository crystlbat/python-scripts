import glob
import os
import time
import json
import random
import requests

input_folder=r"C:\swagger\Transcripts"
swagger_payloads=r"C:\swagger\payloads"
responses_dump=r"C:\swagger\swagger_responses"


input_files=glob.glob(f"{input_folder}\*.txt")
input_names=[]
for file in input_files:
    input_names.append(os.path.basename(file).replace(".txt",""))
print(input_files)
print(input_names)

#input values for swagger
agentId = "2"
org_id_ = "1"
tenantId = "1"
customerId = "12345"
cat_id_ = "1"
agentClientId = "c398990f-9667-4d65-af2c-54192fdfd1b4"
customerClientId = "12345"


swagger_url = "http://172.31.1.199:3330/summary"
params={}
headers = {
        'accept': 'application/json',
    'Content-Type': 'application/json; charset=utf-8'
                }


def transcript_to_word_offset(line_list):
    turns = []
    for index, line in enumerate(line_list):
        turn = {"order": 0, "speaker": "agent", "startOffset": 0, "endOffset": 1, "words": []}
        turn["order"] = index + 1
        turn["speaker"] = line.split(':')[0].strip().lower()
        for word in line.split(':')[1].strip().split('\n'):
            word = {"text": word, "startOffset": 0, "endOffset": 1, "confidence": 0.9}
            turn["words"].append(word)
        turns.append(turn)
    return turns


for file in input_files:
    map_={}
    with open(file,"r") as input:
        lines=input.readlines()
    print(lines)
    map_ = {
        "transcripts":lines,
    }
    random_string = ''.join(random.choice('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ') for i in range(16))
    starttime = int(round(time.time() * 1000))
    final = {"sessionId": random_string,
             "lang": "en-us",
             "startTime": starttime,
             "turns": transcript_to_word_offset(map_['transcripts']),
             "wsText": map_['transcripts'],
             "metadata": {
                 "agentId": agentId,
                 "organizationId": org_id_,
                 "tenantId": tenantId,
                 "customerId": customerId,
                 "contactId": random_string,
                 "categoryId": cat_id_,
                 "type": "test",
                 "contactType": "voice",
                 "convId": random_string,
                 "journeyId": random_string,
                 "isDiarized": True,
                 "contactDuration": 60839,
                 "agentClientId": agentClientId,
                 "customerClientId": customerClientId
             },
             "auxiliaryMetadata": {"startOffset": 12},
             "isChunk": False,
             "isLastChunk": True
             }
    with open(f"{swagger_payloads}\\Payload_{os.path.basename(file).replace('.txt','.json')}", "w") as file:
        file.write(json.dumps(final))


import glob
import os
import time
import json
import random
import requests

headers = {
    'Content-Type': 'application/json',
                }
swagger_url="http://172.31.1.199:3330/summary"


swag_out_path="C:/swagger/swagger_responses"
swagger_payloads=glob.glob("C:/swagger/payloads/*.json")


for file in swagger_payloads:
    with open(file,"r") as input:
        data=json.load(input)
    filename=os.path.basename(file)
    print(filename)
    print(type(data))
    response = requests.post(swagger_url, headers=headers, json=data)
    print(response.json())
    with open(f"{swag_out_path}/response_{filename}","w") as out:
        json.dump(response.json(),out)

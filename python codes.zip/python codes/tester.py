import glob
import os

files=glob.glob(r'C:\Users\Bibin\Downloads\Transcripts- Decklist\*.txt')
print(files)
for file in files:
    with open(file,"r") as input:
        lines=input.readlines()
    print(lines)